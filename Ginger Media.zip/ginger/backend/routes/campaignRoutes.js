
const express = require('express');
const router = express.Router();
const Campaign = require('../models/Campaign');

router.post('/', async (req, res) => {
  try {
    const { name, client, startDate, status } = req.body;
    if (!name || !client || !startDate) return res.status(400).json({ msg: 'Missing fields' });
    const c = new Campaign({ name, client, startDate, status });
    await c.save();
    res.status(201).json(c);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
/*router.patch('/:id/status', async (req, res) => {
  try {
    const { status } = req.body;
    if (!['Active','Paused','Completed'].includes(status)) return res.status(400).json({ error: 'Invalid status' });
    const updated = await Campaign.findByIdAndUpdate(req.params.id, { status }, { new: true });
    res.json(updated);
  } catch (err) { res.status(500).json({ error: err.message }); }
});*/


router.patch('/:id/status', async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    
    const allowed = ['Active', 'Paused', 'Completed'];
    if (!allowed.includes(status)) {
      return res.status(400).json({ message: 'Invalid status' });
    }

    const updated = await Campaign.findByIdAndUpdate(
      id,
      { status },
      { new: true }
    );

    if (!updated) return res.status(404).json({ message: 'Campaign not found' });

    res.json(updated);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});



/*router.get('/', async (req, res) => {
  try {
    const { status, search } = req.query;
    const query = {};
    if (status && ['Active','Paused','Completed'].includes(status)) query.status = status;
    if (search) {
      const re = new RegExp(search, 'i');
      query.$or = [{ name: re }, { client: re }];
    }
    const list = await Campaign.find(query).sort({ createdAt: -1 });
    res.json(list);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});*/

router.get('/', async (req, res) => {
  try {
    const { search } = req.query;
    let query = {};
    if (search) {
      query = {
        $or: [
          { name: { $regex: search, $options: 'i' } },
          { client: { $regex: search, $options: 'i' } }
        ]
      };
    }
    const campaigns = await Campaign.find(query);
    res.json(campaigns);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

router.put('/:id', async (req, res) => {
  try {
    const update = {};
    const allowed = ['name','client','startDate','status'];
    allowed.forEach(k => { if (req.body[k] !== undefined) update[k] = req.body[k]; });
    if (update.status && !['Active','Paused','Completed'].includes(update.status)) 
      return res.status(400).json({ msg: 'Invalid status' });
    const updated = await Campaign.findByIdAndUpdate(req.params.id, update, { new: true });
    res.json(updated);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.delete('/:id', async (req, res) => {
  try {
    await Campaign.findByIdAndDelete(req.params.id);
    res.json({ message: 'Deleted' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
