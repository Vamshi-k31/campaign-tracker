#  Campaign Tracker — GoGig Internship Task

##  Objective
A simple full-stack web app to **create, track, and manage marketing campaigns**.  
Built as part of the **GoGig.in Software Developer Intern Technical Task**.

---

##  Features

 Add a new marketing campaign  
 View all campaigns in a clean list/table  
 Update campaign status (Active / Paused / Completed)  
 Delete a campaign  
 Search and filter campaigns by name/client  
 Dashboard summary (Active, Paused, Completed counts)  
 Persistent storage in MongoDB  
 *Bonus:* Search & summary dashboard added  

---

## Tech Stack

| Layer | Technology |
|--------|-------------|
| Frontend | React, Axios, HTML5, CSS3 |
| Backend | Node.js, Express |
| Database | MongoDB (Mongoose ORM) |
| Styling | Custom CSS (responsive layout) |

---

## Folder Structure

```
ginger/
├── backend/
│   ├── server.js
│   ├── routes/
│   │   └── campaignRoutes.js
│   ├── models/
│   │   └── Campaign.js
│   ├── package.json
│
├── frontend/
│   ├── src/
│   │   ├── App.js
│   │   ├── api.js
│   │   ├── components/
│   │   │   ├── CampaignForm.js
│   │   │   ├── CampaignList.js
│   │   │   └── style.css
│   ├── package.json
│
└── README.md
```

---

## How It Works

1. **Backend (Express API)**  
   Provides REST endpoints:  
   - `GET /` ->Get all campaigns (supports search/filter)  
   - `POST /` -> Add new campaign  
   - `PATCH /:id/status` -> Update campaign status  
   - `DELETE /:id` -> Delete campaign  

2. **Frontend (React App)**  
   - Displays campaign list with real-time updates.  
   - Uses Axios for API calls.  
   - Includes a form for adding campaigns.  
   - Shows dashboard summary of campaign statuses.  

3. **Database (MongoDB)**  
   - Stores campaign details (`name`, `client`, `startDate`, `status`).  
   - Uses Mongoose schema for structure and validation.  

---

## Setup & Installation

### Clone the repository
```bash
git clone https://github.com/<your-username>/campaign-tracker.git
cd campaign-tracker
```

###  Install dependencies
#### Backend:
```bash
cd backend
npm install
```
#### Frontend:
```bash
cd ../frontend
npm install
```

###  Configure environment variables
Create a `.env` file inside `/backend`:
```
PORT=5000
MONGO_URI=mongodb://127.0.0.1:27017/campaignTracker
```

###  Run the app
In two separate terminals:

**Backend:**
```bash
cd backend
npm start
```

**Frontend:**
```bash
cd frontend
npm start
```

The React app runs at  `http://localhost:3000`  
The Express API runs at  `http://localhost:5000`

---

## API Routes Summary

| Method | Endpoint | Description |
|--------|-----------|-------------|
| GET | `/` | Fetch all campaigns (with optional `search` / `status` query) |
| POST | `/` | Add a new campaign |
| PATCH | `/:id/status` | Update campaign status |
| DELETE | `/:id` | Delete a campaign |

___

## Dashboard Summary

Displays real-time counts for:
- Active Campaigns  
- Paused Campaigns  
- Completed Campaigns  

Example:
Active: 3 | Paused: 1 | Completed: 2

____

## Thought Process & Learnings

> Focused on designing a **clear structure** for both frontend and backend.  
> Implemented modular routes and reusable React components.  
> Learned how to connect React with Express using Axios and manage state updates dynamically.  
> Ensured clean UI and proper data persistence in MongoDB.  

____

Vamshi 
vamshik3110@gmail.com 
 
